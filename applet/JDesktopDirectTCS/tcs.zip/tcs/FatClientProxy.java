package com.desktopdirect.tcs;

import java.awt.*;
import java.awt.event.*;
import java.applet.*;
import java.io.*;
import java.net.*;
import java.util.*;


import crysec.*;
import crysec.SSL.*;

public class FatClientProxy implements Runnable {

	TextField _field, password_field, domain_field;
	String username, password, domain;
	Button login_button;

	String session_id;
        String session_cookie;
        String mod_id;
	String server_name, proxy_host;
	int server_port, proxy_port;

	Thread server_thread;
	FCP_KeepAlive keeper;

	short[] ciphers;
	SSLParams params;
	SSLSocket sslsock;
	SpinnerRandomBitsSource spinner;

	Socket sock;
	InputStream sp_in;
	OutputStream sp_out;
	BufferedOutputStream buff_out;
        
	boolean valid_session;
	boolean conn_alive;
	boolean was_started;
	boolean do_authentication;
	boolean need_credentials;
	boolean ready_notified;
        boolean m_Ready;

	private final int MAX_LOCAL_MSS = 800; //MacOS TCP STACK SUX0RZ!!!

	//these must sync with server side fcp_server.h #defines
	private final byte FCP_VERSION_ID = 9;

	private final byte CLIENT_INITIATE   = 0;
	private final byte VALIDATE_VERSION  = 1;
	private final byte SET_MAPPED_HOSTS  = 2;
	private final byte SET_LISTEN_PORTS  = 3;
	//private final byte CONNECTION_OPENED = 4;
	private final byte CONNECTION_READY  = 5;
	private final byte SEND_DATA         = 6;
	private final byte CONNECTION_CLOSED = 7;
	private final byte START_WINREDIR    = 8;
	private final byte WINREDIR_OPENED   = 9;
	private final byte WINREDIR_RESOLVE  = 10;
	private final byte SESSION_TIMEOUT   = 11;
	private final byte SESSION_INVALID   = 12;
	private final byte SESSION_KEEPALIVE = 13;
	private final byte FCP_HEADER_ACK    = 14;
        private final byte START_TCS         = 15;
        private final byte IDENTIFY_MODULE   = 16;
        private final byte GET_SITEID        = 17;
        private final byte GET_USERNAME      = 18;
        private final byte GET_PASSWORD      = 19;
        private final byte RESOLVE_HOSTNAME  = 20;
        private final byte ACCEPT_CONNECTION = 21;
        private final byte FCP_GEN_LOG       = 22;
        private final byte GET_TIME_INFO     = 23;
        private final byte RESET_TIMERS      = 25;


        
	private final byte FCP_HEADER_LEN = 13;

	private final byte ACTION_CODE_OFFSET = 0;
	private final byte LOCALHOSTIP_OFFSET = 1;
	private final byte LISTEN_PORT_OFFSET = 5;
	private final byte REMOTE_PORT_OFFSET = 7;
	private final byte DATA_LENGTH_OFFSET = 9;
	private final byte DATA_REGION_OFFSET = 13;

	//these values are from Windows (Visual Studio 6)
	public static final byte IPPROTO_TCP = 6; //always this for now
	public static final byte IPPROTO_UDP = 17;

	//these must sync with the winredir constants
	public static final byte WINREDIR_DATA_PORT = 0;
	public static final byte WINREDIR_DNS_HOSTS = 1; //not used yet
	public static final byte WINREDIR_IP_PORTS  = 2;
	public static final byte WINREDIR_EXE_MD5   = 3;
	public static final byte WINREDIR_NEW_CONN  = 4;
	public static final byte WINREDIR_KEEPALIVE = 5;
	public static final byte WINREDIR_SHUTDOWN  = 6;
	public static final byte WINREDIR_CONFIGEND = 7;
	public static final byte WINREDIR_SP_IP     = 8;
	public static final byte WINREDIR_HOSTNAME  = 9;
	public static final byte WINREDIR_ADDRESS   = 10;

	//these are used for internal print_message controls
	public static final byte INFO_ALL      = 0;
	public static final byte INFO_NOTICE   = 1;
	public static final byte INFO_WARNING  = 2;
	public static final byte INFO_ERROR    = 3;
	public static final byte INFO_CRITICAL = 4;
	public static final byte INFO_FAILURE  = 5;
	public static final byte INFO_STATUS   = 6;
	public static final byte INFO_NONE     = 7;

        public static final String LOCALHOST_ADDR = "127.0.0.1";
        public static final int INTERNAL_PORT     = 135;
        
        public Hashtable     m_Conns;
        int                  m_LastPort;
        
	public byte importance_threshold;

	//these are for delinaating our hosts additions
	private final String START_AN_HOSTS = "#Begin ArrayNetworks Entries";
	private final String STOP_AN_HOSTS =  "#End ArrayNetworks Entries";
        
        netscape.javascript.JSObject win;
        
        PipedOutputStream m_ResolveHostResult = null;
        PipedOutputStream m_GetTimersResult = null;
        PipedOutputStream m_GetUsernameResult = null;
        PipedOutputStream m_GetPasswordResult = null;
        PipedOutputStream m_AddConnResultOut = null;
        PipedInputStream m_AddConnResultIn = null;
        
        int m_LastIdleTimer = 0;
        int m_LastLifetimeTimer = 0;

public FatClientProxy(netscape.javascript.JSObject prmWin, String prmServer, int prmPort, String prmSessionID, String prmSessionCookie, String prmModID) {
  win = prmWin;
  print_message("Init Host: "+server_name, INFO_NOTICE);
  server_name = prmServer;
  server_port = prmPort;
  session_id = prmSessionID;
  mod_id = prmModID;  
  session_cookie = prmSessionCookie;
  m_LastPort = 1;
  m_Ready = false;
  
  m_Conns = new Hashtable((int)5, (float)0.9);
}

public void setDefaultCredentials(String prmUsername, String prmPassword, String prmDomain) {
    username = prmUsername;
    password = prmPassword;
    domain = prmDomain;
}

public void setSessionCookie(String prmCookie){
  session_cookie = prmCookie;
  
  int i = session_cookie.indexOf("=");
  if (i > -1) {
    session_id = session_cookie.substring(i+1);
  }                
}
        
//display a message in the event log
public void print_message(String msg, byte importance)
{
  //System.out.print(msg);
  //System.err.println(msg);
}

//avoid String.getBytes due to utf-8 bug in jdk 1.1
public static byte[] str2bytes(String str)
{
	char[] chars = str.toCharArray();
	byte[] bytes = new byte[chars.length];

	int i;
	for (i = 0; i < chars.length; i++) {
		bytes[i] = (byte)(chars[i] & 0xFF);
	}

	return bytes;
}

//convert C-string (1 byte char) into Java-string (2 byte char)
public static String bytes2str(byte[] bytes, int offset, int len)
{
	int i;
	byte[] temp = new byte[1];
	String return_str = new String("");

	for (i = offset; i < offset+len; i++) {
		temp[0] = bytes[i];
		if (temp[0] == 0) {
			break; //reached null terminator
		}
		return_str += new String(temp);
	}

	return return_str;
}

//convert from int to bytes in network order (BE)
public static byte[] int2bytes(int num, int len)
{
	int i;
	byte[] bytes = new byte[len];

	for (i = (len-1)*8; i >= 0; i -= 8) {
		bytes[(len-1) - i/8] = (byte)((num >> i) & 0xFF);
	}

	return bytes;
}

//convert from bytes in network order (BE) to int
public static int bytes2int(byte[] bytes, int offset, int len)
{
	int i, num = 0;
	int[] mask = new int[4];

	mask[0] = 0xFF000000;
	mask[1] = 0x00FF0000;
	mask[2] = 0x0000FF00;
	mask[3] = 0x000000FF;

	for (i = (len-1)*8; i >= 0; i -= 8) {
		num |= ((int)bytes[offset + (len-1) - i/8] << i) & mask[3 - i/8];
	}

	return num;
}

//construct the packet header
private byte[] make_header(byte action_code, int local_ip,
                           int listen_port, int remote_port, int len)
{
	byte[] packet_header;
	byte[] temp;

	packet_header = new byte[13];
	packet_header[0] = action_code;

	temp = int2bytes(local_ip, 4);
	packet_header[1] = temp[0];
	packet_header[2] = temp[1];
	packet_header[3] = temp[2];
	packet_header[4] = temp[3];

	temp = int2bytes(listen_port, 2);
	packet_header[5] = temp[0];
	packet_header[6] = temp[1];

	temp = int2bytes(remote_port, 2);
	packet_header[7] = temp[0];
	packet_header[8] = temp[1];

	temp = int2bytes(len, 4);
	packet_header[9] = temp[0];
	packet_header[10] = temp[1];
	packet_header[11] = temp[2];
	packet_header[12] = temp[3];

	return packet_header;
}


private void notify_ready()
{
	//attempt to do any redirection of the parent window if needed
	if (!ready_notified) try {
		win.call("do_redir",null);
		ready_notified = true;
	} catch (Exception ignored) {
	}
}

public void init()
{
	//initialize global variables to default values
	sock = null;
	sslsock = null;
	keeper = null;

	username = null;
	password = null;
	domain = null;
	login_button = null;
	do_authentication = false;
	need_credentials = false;

	was_started = false;
	conn_alive = false;
	valid_session = true;
	ready_notified = false;

 	importance_threshold = INFO_CRITICAL;

	//do general startup operations
	try {
		//initialize the SSL parameters
		ciphers = new short[1];
		ciphers[0] = SSLParams.SSL_RSA_WITH_RC4_128_MD5;

		print_message("Initializing SSL...\n", INFO_NOTICE);
		spinner = new SpinnerRandomBitsSource(10);

		params = new SSLParams();
		params.setRNG(spinner);
		params.setClientCipherSuites(ciphers);
		params.setCertVerifier(new SSLCertificateVerifier(false));
		params.setAllowSSL3(false);
		params.setAllowTLS1(true);

		//ready a thread for execution - this would be FCP_ServerThread
		//print_message("Spooling Up...\n", INFO_NOTICE);
                //server_thread = new Thread();
                
		server_thread = new Thread(this); //the thread to read from the SP
		server_thread.start();
		was_started = true; //the try succeeded
	} catch (Exception e) {
		print_message("Failure because: "+e.getMessage()+"\n", INFO_FAILURE);
	}
}

private Socket init_control_connection()
{
	Socket sock; //we could use the global one but...
	int status = 0;

	//try to detect and handle any forward proxies
        print_message("Host: "+server_name, INFO_NOTICE);
	DetectProxy proxy = new DetectProxy(this, server_name, server_port, null);
	proxy_host = proxy.getHost();
        print_message("Proxy Host: "+proxy_host, INFO_NOTICE);
	proxy_port = proxy.getPort();

	try {
		sock = new Socket(proxy_host, proxy_port);
	} catch (Exception e) {
		print_message("Couldn't create socket: " + e.getMessage() + "\n", INFO_NOTICE);
		return null;
	}

	if (proxy_host.compareTo(server_name) == 0 && proxy_port == server_port) {
		print_message("using direct\n", INFO_NOTICE);
		return sock;
	} else try {
		boolean doing_basic = false;
		boolean doing_ntlm = false;
		String auth_method = "<none>";
		int morebytes = 0;

		print_message("using proxy\n", INFO_NOTICE);
		sp_in = sock.getInputStream();
		sp_out = sock.getOutputStream();
		BufferedReader reader = new BufferedReader(new InputStreamReader(sp_in));
		buff_out = new BufferedOutputStream(sp_out, 1460);

		//uncomment to authenticate against a non-proxy host
		//String connect = "GET / HTTP/1.0\r\n";
		//String keepalive = "Connection: Keep-Alive\r\n\r\n";
		//uncomment to authenticate against a proxy host
		String connect = "CONNECT "+server_name+":"+server_port+" HTTP/1.0\r\n";
		String keepalive = "Proxy-Connection: Keep-Alive\r\n\r\n";

		//send the CONNECT call
		buff_out.write(str2bytes(connect), 0, connect.length()); //since we use 1-byte chars
		buff_out.write(str2bytes(keepalive), 0, keepalive.length()); //since we use 1-byte chars
		buff_out.flush(); //no more to write
		print_message("CONNECT sent\n", INFO_NOTICE);

		//read the response
		String header;
		while ((header = reader.readLine()) != null) {
			print_message("["+header+"]\n", INFO_NOTICE);
			if (header.length() == 0) {
				break; //end of headers
			}
			header.trim();
			if (header.toUpperCase().startsWith("HTTP")) {
				if (header.indexOf("200") > -1) {
					//connection established
					status = 200;
				}
				else if (header.indexOf("407") > -1 || header.indexOf("401") > -1) {
					//we need to authenticate
					status = 407;
				}
				else {
					//bad HTTP status code
					status = 500;
				}
				print_message("HTTP status " + status + "\n", INFO_NOTICE);
			}
			if (header.indexOf(":") < 1) {
				continue; //not a header of form name: value
			}
			if (header.toLowerCase().startsWith("content-length")) {
				//we should never get this from a proxy, but oh well
				morebytes = Integer.parseInt(header.substring(header.indexOf(":")+1).trim());
			}
			//uncomment to authenticate against a non-proxy host
			//if (header.startsWith("WWW-Authenticate") || header.startsWith("www-authenticate")) {
			//uncomment to authenticate against a proxy host
			if (header.toLowerCase().startsWith("proxy-authenticate")) {
				auth_method = header.substring(header.indexOf(":")+1).trim();
				//find out our authentication option(s) - choose the first of either Basic or NTLM
				if (auth_method.toLowerCase().startsWith("basic")) {
					if (!doing_ntlm) {
						doing_basic = true;
						print_message("doing basic auth\n", INFO_NOTICE);
					}
				}
				if (auth_method.toUpperCase().startsWith("NTLM")) {
					if (!doing_basic) {
						doing_ntlm = true;
						print_message("doing ntlm auth\n", INFO_NOTICE);
					}
				}
			}
		}
		if (morebytes > 0) {
			//flush the socket buffer
			print_message("flushing "+morebytes+" bytes\n", INFO_NOTICE);
			reader.skip((long)morebytes);
		}
		if (status != 200) {
			sock.close();
			sock = null;
		}
		if (status == 407) {
			if (doing_basic) {
				sock = negotiate_basic(proxy_host, proxy_port);
			} else if (doing_ntlm) {
				sock = negotiate_ntlm(proxy_host, proxy_port);
			} else {
				//unsupported authentication scheme
				print_message("Unsupported Proxy Authentication method '"+auth_method+"'\n", INFO_STATUS);
			}
		}
	} catch (Exception e) {
		print_message("Error connecting to proxy: " + e.getMessage() + "\n", INFO_NOTICE);
		sock = null;
	}

	if (sock == null && status == 407) {
		print_message("Unable to authenticate with the Proxy.\n"+
		              "Please verify your login information.\n", INFO_STATUS);
	}
	return sock;
}

private void get_user_credentials(boolean doing_ntlm, String msg)
{
	//bring the window to the top in case it was hidden
	try {
		win.call("self.focus",null);
	} catch (Exception ignored) {
	}
        
        DlgUserCred dlg;
        
        dlg = new DlgUserCred(new javax.swing.JFrame(), true);
        dlg.setVisible(true);
        if (dlg.getReturnStatus() == dlg.RET_OK) {
          username = dlg.getUserName();
          password = dlg.getPassword();
        }
        
        

	//wait until the user clicks the Login button
	/*need_credentials = true;
	while (need_credentials) {
		try {
			server_thread.sleep((long)100);
		} catch (Exception e) {
		}
	}*/

	
	print_message("Credentials: "+username+","+password+","+domain+"\n", INFO_NOTICE);
	print_message("Authenticating to Proxy...\n", INFO_STATUS);
}

public void start()
{
	if (!was_started) {
		print_message("An error occurred and the Applet cannot be started!\n", INFO_STATUS);
	} 
}

public void run()
{
	//Hashtable listeners;
	//FCP_AcceptThread listener;
        FCP_AcceptThread conn;
	int iterations;

	long time = (new Date()).getTime();
	int starttime = (int)(time / 1000); //convert miliseconds to seconds

	int len;
	byte[] data_header, data_payload;
	byte[] ip_arr;

	byte action_code;
	int local_ip;
	int listen_port, remote_port;
	int data_length;

	data_header = new byte[FCP_HEADER_LEN];
	data_payload = new byte[MAX_LOCAL_MSS];

	iterations = 0;

	print_message("Connecting to Server...\n", INFO_STATUS);
	while (valid_session) {
		try {
			if (!conn_alive) {
				byte[] sessid_array;

				if (starttime == 0) {
					time = (new Date()).getTime();
					starttime = (int)(time / 1000); //convert miliseconds to seconds
				}

				//open a connection to the SP on the control port
				sock = init_control_connection();
				if (sock == null) {
					throw new Exception("Unable to open control connection");
				}

				//disable client cert authentication if it is enabled
				sock = ssl_disable_client_cert(sock);
				if (sock == null) {
					throw new Exception("Unable to initialize control connection");
				}

				//restart doing SSL on the connection
				sslsock = new SSLSocket(sock, params);
				sp_in = sslsock.getInputStream();
				sp_out = sslsock.getOutputStream();
				buff_out = new BufferedOutputStream(sp_out, 1460);

                                /*
				String cookies = "";
				//attempt to extract all SP set cookies from the browser
				try {
					cookies = (String)win.call("get_cookies",null);
				} catch (Exception ignored) {
				}
				if (cookies == null) {
					cookies = "";
				}
				cookies.replace('\r', ' ');
				cookies.replace('\n', ' ');*/

				//send the request to initiate the clientapp control connection
				String capp_request = "GET /prx/000/http/localhost/clientappcontrol HTTP/1.0\r\n" +
				                      "Connection: Keep-Alive\r\n" +
				                      "Cookie: " + session_cookie + "\r\n\r\n";
				buff_out.write(str2bytes(capp_request), 0, capp_request.length());
				buff_out.flush();

				//pull the SP proxy response out
				String capp_response = "HTTP/1.1 200 Connection Established\r\n\r\n";
				sp_in.skip((long)capp_response.length());

				//finally start our internal initiation sequence
				action_code = START_TCS;

				//strip off the siteid and + delimiter
				//XXX need to fix: see bug 8732
				sessid_array = str2bytes(session_id.substring(session_id.indexOf("+")+1));
				data_header = make_header(action_code, 0, 0, 0, sessid_array.length);

				buff_out.write(data_header, 0, data_header.length);
				buff_out.write(sessid_array, 0, sessid_array.length);
				buff_out.flush();

				conn_alive = true;
				iterations = 0;
				starttime = 0;

				try {
					keeper = new FCP_KeepAlive(this, (long)60000);
					keeper.start();
				} catch (Exception e) {
					print_message("Could not start Keep-Alive timer!\n", INFO_ERROR);
				}
			}

			//don't starve other threads
			iterations++;
			if (iterations > 10) {
				server_thread.yield();
				iterations = 0;
			}

			//read in the packet header
			len = 0;
			while (len < FCP_HEADER_LEN) {
				len += sp_in.read(data_header, len, FCP_HEADER_LEN-len);
			}
			//extract the values
			action_code = data_header[ACTION_CODE_OFFSET];
			local_ip    = bytes2int(data_header, LOCALHOSTIP_OFFSET, 4);
			listen_port = bytes2int(data_header, LISTEN_PORT_OFFSET, 2);
			remote_port = bytes2int(data_header, REMOTE_PORT_OFFSET, 2);
			data_length = bytes2int(data_header, DATA_LENGTH_OFFSET, 4);
                        int read_len;
                        String tmps;
                        String resSt = "";

			//decide what to do with it
			switch (action_code) {
				case FCP_HEADER_ACK:
                                  print_message("Server ACK: ("+action_code+","+listen_port+
                                                ","+remote_port+","+data_length+")\n", INFO_NOTICE);
                                  break;
                                  
                               case CONNECTION_READY:
                                 if (m_AddConnResultOut != null) {
                                   m_AddConnResultOut.write(1);
                                 }
                                 break;
                                
                               case RESOLVE_HOSTNAME:
                                 if (m_ResolveHostResult != null) {
                                   m_ResolveHostResult.write(int2bytes(local_ip, 4), 0, 4);
                                 }
                                 
                                 break;
                                 
                                 
                               case GET_TIME_INFO:  
                                 if (m_GetTimersResult != null) {
                                   m_GetTimersResult.write(int2bytes(local_ip, 4), 0, 4);
                                   m_GetTimersResult.write(int2bytes(data_length, 4), 0, 4);
                                   data_length = 0;
                                 }
                                 
                                 break;
                               case GET_USERNAME:
                                     
                                 //read in the packet payload (data)
                                 while (data_length > 0) {
                                   if (data_length > MAX_LOCAL_MSS) {
                                     read_len = MAX_LOCAL_MSS;
                                   } else {
                                     read_len = data_length;
                                   }
                                   len = sp_in.read(data_payload, 0, read_len);
                                   tmps = new String(data_payload, 0, len);
                                   resSt = resSt+tmps;
                                   data_length -= len;
                                 }
                                 if (m_GetUsernameResult != null) {
                                   m_GetUsernameResult.write(resSt.getBytes(), 0, resSt.length());
                                   m_GetUsernameResult.write(0);
                                 }
                                 break;
                               case GET_PASSWORD:
                                     
                                 //read in the packet payload (data)
                                 while (data_length > 0) {
                                   if (data_length > MAX_LOCAL_MSS) {
                                     read_len = MAX_LOCAL_MSS;
                                   } else {
                                     read_len = data_length;
                                   }
                                   len = sp_in.read(data_payload, 0, read_len);
                                   tmps = new String(data_payload, 0, len);
                                   resSt = resSt+tmps;
                                   data_length -= len;
                                 }
                                 if (m_GetPasswordResult != null) {
                                   m_GetPasswordResult.write(resSt.getBytes(), 0, resSt.length());
                                   m_GetPasswordResult.write(0);
                                 }
                                
                                 break;
                                  
				case SEND_DATA:
                                   conn = (FCP_AcceptThread )m_Conns.get(new Integer(remote_port));
                                   if (conn != null) {
                                     
                                     //read in the packet payload (data)
                                     while (data_length > 0) {
                                       if (data_length > MAX_LOCAL_MSS) {
                                         read_len = MAX_LOCAL_MSS;
                                       } else {
                                         read_len = data_length;
                                       }
                                       len = sp_in.read(data_payload, 0, read_len);
                                       conn.send_to_client(remote_port, len, data_payload);
                                       data_length -= len;
                                     }
                                   }
                                   break;
				case CONNECTION_CLOSED:
                                   conn = (FCP_AcceptThread )m_Conns.get(new Integer(remote_port));
                                   if (conn != null) {
                                     conn.close_client(remote_port);
                                   }
                                   break;
				case WINREDIR_ADDRESS:
					byte[] domain = null;

					if (data_length > 0) {
						domain = new byte[data_length];
						//read in the packet payload (data)
						len = 0;
						while (len < data_length) {
							len += sp_in.read(domain, len, data_length-len);
						}
					}
					ip_arr = int2bytes(local_ip, 4);
					print_message("Resolved " + bytes2str(domain, 0, data_length) + "to " +
					              new String(((int)ip_arr[0] & 0xFF) + "." + ((int)ip_arr[1] & 0xFF) + "." +
					                         ((int)ip_arr[2] & 0xFF) + "." + ((int)ip_arr[3] & 0xFF)) +
					              " for Query ID " + listen_port + " SPI port " + remote_port + "\n", INFO_NOTICE);
					//overload listen_port as the query id
					break;
                                        
				case VALIDATE_VERSION:
					generic_send(IDENTIFY_MODULE, 0, 0, 0, mod_id.length(), mod_id.getBytes());
                                        m_Ready = true;                                      
					break;
				case SESSION_TIMEOUT:
					valid_session = false;
					terminate();
					logout();
					print_message("Your session has timed out.\n"+
					              "Please close this window and "+
					              "log back in.", INFO_STATUS);
					break;
				case SESSION_INVALID:
					valid_session = false;
					terminate();
					logout();
					print_message("Your session is invalid!\n"+
					              "Please close this window and "+
					              "log back in.", INFO_STATUS);
					break;
				default: //should never happen
					valid_session = false;
					terminate();
					print_message("Could not understand the Server!\n"+
						          "Please close this window, clear your\n" +
						          "browser cache, and try again.\n", INFO_STATUS);
					break;
			}
		} catch (Exception e) {
			print_message("Problem with Server connection: "+e.getMessage()+"\n", INFO_CRITICAL);
			terminate(); //all our connections are hosed now anyway
			conn_alive = false; //we'll try to reopen the next loop

			time = (new Date()).getTime();
			int currtime = (int)(time / 1000); //convert miliseconds to seconds
			if (starttime != 0 && currtime - starttime > 120) {
				valid_session = false; //give up after 120 seconds
				print_message("Cannot connect to Server at this time.\n"+
				              "Please close this window and try again\n"+
				              "later; if this problem persists, contact\n"+
				              "your network administrator.", INFO_STATUS);
			}
			try {
				if (sock != null) sock.close();
				if (sslsock != null) sslsock.close();
			} catch (Exception ignored) {
			}
			try {
				//sleep 5 seconds
				print_message("Retrying Server connection...\n", INFO_STATUS);
				server_thread.sleep((long)5000);
			} catch (Exception ignored) {
			}
		}
	}

	//automatically close the applet window in case of error
	//don't do this in destroy(), since that's only called
	//if the user is already manually closing the window
	try {
		win.call("do_shutdown",null);
	} catch (Exception ignored) {
	}
}


private synchronized void generic_send(byte action_code, int local_ip,
                                       int listen_port, int remote_port,
                                       int len, byte[] data)
{
	byte[] data_header;
	byte[] temp;

	try {
		//send the data
		data_header = make_header(action_code, local_ip, listen_port, remote_port, len);
		buff_out.write(data_header, 0, data_header.length);
		if (data != null) buff_out.write(data, 0, len);
		buff_out.flush(); //no more to write
	} catch (Exception e) {
           System.err.println("Error during send: "+e.getMessage()+"\n");
           print_message("Error during send: "+e.getMessage()+"\n", INFO_ERROR);
	}
}

public synchronized int nextAvailPort() {
  int i = m_LastPort;
  
  while (true) {
    if (m_Conns.get(new Integer(i)) == null) {
      m_LastPort = i+1;
      return i;
    }
    i++;
    if (i > 60000) {
      i = 1;
    }
  }

}

public synchronized int addConn(String prmDestIP, int prmDestPort, int prmSrcPort) {
  
  m_AddConnResultOut = new PipedOutputStream();
  m_AddConnResultIn = new PipedInputStream();
  
  print_message("Creating accesspt thread \n", INFO_NOTICE);
  FCP_AcceptThread conn = new FCP_AcceptThread(this, LOCALHOST_ADDR);
  print_message("Accept thread created \n", INFO_NOTICE);
  if (conn.getListenPort() > 0) {
    print_message("Listen port is ok \n", INFO_NOTICE);    
    //m_Conns.put(new Integer(c), conn);
    //conn.start();

    try {
      print_message("Connecting to result pipe \n", INFO_NOTICE);    
      m_AddConnResultIn.connect(m_AddConnResultOut);
      print_message("Creating WinRedirEntry \n", INFO_NOTICE);
      FCP_WinRedirEntry entry = new FCP_WinRedirEntry(0, prmDestPort, bytes2int(InetAddress.getByName(prmDestIP).getAddress(), 0, 4));
      print_message("Setting connection entry \n", INFO_NOTICE);
      conn.setEntry(entry);
      print_message("Starting connection \n", INFO_NOTICE);
      conn.start();
      //winredir_connect(bytes2int(InetAddress.getByName(LOCALHOST_ADDR).getAddress(), 0, 4),INTERNAL_PORT, c, entry.encode().length, entry.encode());

      return conn.getListenPort();
     
    } catch (Exception e) {
      //m_Conns.remove(new Integer(c));
    }
  }

  return -1;
}

public boolean isAddConnOK() {
 try {
   return (m_AddConnResultIn.available() > 0);
 } catch (Exception e) {
  
 }
 
 return false;
}


public synchronized String resolveHost(String prmHost) {

  // Creates the output and input pipes needed to get the result to the requesting class
  int i, c; 
  //byte resIP[] = new byte[4];
  //String resIP = "";
  String resSt = "";
  m_ResolveHostResult = new PipedOutputStream();
  PipedInputStream res = new PipedInputStream();
  
  
  try {
    res.connect(m_ResolveHostResult);
    generic_send(RESOLVE_HOSTNAME, 0, 0, 0, prmHost.length(), prmHost.getBytes());
    
    Integer ai;
    c = 0;
    do {
      i = res.read();
      if (i == -1) {
        return "";
      }
      
      ai = new Integer(i);
      resSt = resSt + ai.toString();
      if (c < 3) {
        resSt = resSt+".";
      }
      //resIP[c] = (byte)i; 
      c++;
    } while (c < 4);
  
    
    /*resSt = InetAddress.getByName(resIP).toString();
    if (resSt.length() > 1) {
      resSt = resSt.substring(1);
    }*/
  } catch (Exception e) {
   
  }
  
  return resSt;
}

public synchronized void updateTimers() {
  // Creates the output and input pipes needed to get the result to the requesting class
  int i = 0;
  int c;
  byte b[] = new byte[4];
  m_GetTimersResult = new PipedOutputStream();
  PipedInputStream res = new PipedInputStream();
  
  
  try {
    res.connect(m_GetTimersResult);
    generic_send(GET_TIME_INFO, 0, 0, 0, 0, (byte[])null);
    
    c = 3;
    do {
      i = res.read();
      if (i == -1) {
        return;
      }
      b[c] = (byte)i;
      c--;
    } while (c >= 0);
    
    m_LastIdleTimer = bytes2int(b, 0, 4);
    
    c = 0;
    do {
      i = res.read();
      if (i == -1) {
        return;
      }
      
      b[c] = (byte)i;
      c++;
    } while (c < 4);
    
    m_LastLifetimeTimer = bytes2int(b, 0, 4);
  
  } catch (Exception e) {
   
  }

  return;  
}

public synchronized int getIdleTimer() {

  return m_LastIdleTimer;
}

public synchronized int getLifetimeTimer() {

  return m_LastLifetimeTimer;
}

public synchronized void resetTimers(int prmSecs) {

  generic_send(RESET_TIMERS, prmSecs, 0, 0, 0, (byte[])null);
  
}

public synchronized String getUsername() {

  // Creates the output and input pipes needed to get the result to the requesting class
  int i;
  String resSt = "";
  m_GetUsernameResult = new PipedOutputStream();
  PipedInputStream res = new PipedInputStream();
  
  
  try {
    res.connect(m_GetUsernameResult);
    generic_send(GET_USERNAME, 0, 0, 0, 0, (byte[])null);
    
    while (true) {
      i = res.read();
      if ((i == -1) || (i == 0)) {
        return resSt;
      }
      resSt = resSt + String.valueOf((char)i);
    }
  
  } catch (Exception e) {
   
  }

  return resSt;
}

public synchronized String getPassword() {

  // Creates the output and input pipes needed to get the result to the requesting class
  int i;
  String resSt = "";
  m_GetPasswordResult = new PipedOutputStream();
  PipedInputStream res = new PipedInputStream();
  
  
  try {
    res.connect(m_GetPasswordResult);
    generic_send(GET_PASSWORD, 0, 0, 0, 0, (byte[])null);
    
    while (true) {
      i = res.read();
      if ((i == -1) || (i == 0)) {
        return resSt;
      }
      resSt = resSt + String.valueOf((char)i);
    }
  
  } catch (Exception e) {
   
  }

  return resSt;
}

public void keepalive()
{
	byte action_code = SESSION_KEEPALIVE;
	print_message("Keep-Alive triggered...\n", INFO_NOTICE);
	generic_send(action_code, (int)0, (int)0, (int)0, (int)0, (byte[])null);
}

/*public void client_connect(int local_ip, int listen_port, int remote_port)
{
	byte action_code = CONNECTION_OPENED;
	generic_send(action_code, local_ip, listen_port, remote_port, (int)0, (byte[])null);
}*/

public void winredir_connect(int local_ip, int listen_port, int remote_port, int len, byte[] data)
{
	byte action_code = WINREDIR_OPENED;
	generic_send(action_code, local_ip, listen_port, remote_port, len, data);
}

public void winredir_resolve(int queryid, int remote_port, byte[] hostname)
{
	byte action_code = WINREDIR_RESOLVE;
	generic_send(action_code, (int)0, queryid, remote_port, hostname.length, hostname);
}

public void send(int local_ip, int listen_port, int remote_port, int len, byte[] data)
{
	byte action_code = SEND_DATA;
	if (keeper != null) {
		keeper.need_keepalive = false;
	}
	generic_send(action_code, local_ip, listen_port, remote_port, len, data);
}

public void close_server(int local_ip, int listen_port, int remote_port)
{
	byte action_code = CONNECTION_CLOSED;
	generic_send(action_code, local_ip, listen_port, remote_port, (int)0, (byte[])null);
}

public synchronized void remove(FCP_AcceptThread listener)
{
	Hashtable listeners;
	try {
/*		listeners = (Hashtable)localhosts.get(new Integer(listener.local_ip));
		if (listeners != null) {
			listeners.remove(new Integer(listener.listen_port));
		} else {
			throw new Exception("Local IP not found in hosts table.");
		}*/
	} catch (Exception e) {
		print_message("While deleting accept: "+e.getMessage()+"\n", INFO_WARNING);
	}
}

private void logout()
{
try {
	//open a connection to the SP (assumes the virtual site port)
	print_message("Connecting to Server...\n", INFO_STATUS);
	sock = init_control_connection();
	if (sock == null) {
		return;
	}

	//start doing SSL on the connection
	sslsock = new SSLSocket(sock, params);
	sp_in = sslsock.getInputStream();
	sp_out = sslsock.getOutputStream();
	buff_out = new BufferedOutputStream(sp_out, 1460);

	String cookies = "";
	//attempt to extract all SP set cookies from the browser
	try {
		cookies = (String)win.call("get_cookies",null);
	} catch (Exception ignored) {
	}
	if (cookies == null) {
		cookies = "";
	}
	cookies.replace('\r', ' ');
	cookies.replace('\n', ' ');
	//remove the session cookie for SP2 in dual SP mode (or SP1 in single)
	int pos = cookies.indexOf(session_id);
	String prefix = cookies.substring(0, pos);
	String suffix = cookies.substring(pos + session_id.length());
	cookies = prefix + "fakeid" + suffix;

	//send the request to initiate the clientapp control connection
	String capp_request = "GET /prx/000/http/localhost/logout HTTP/1.0\r\n" +
	                      "Connection: Close\r\n" +
	                      "Cookie: " + cookies + "\r\n\r\n";
	buff_out.write(str2bytes(capp_request), 0, capp_request.length());
	buff_out.flush();

	//close the connection - discard response
	sslsock.close();

} catch (Exception ignored) { }
}

public synchronized void terminate()
{
	FCP_AcceptThread listener;

	importance_threshold = INFO_NONE; //stop all further output

	try {
		if (keeper != null) {
			keeper.terminate();
		}
	} catch (Exception ignored) {
	}
	try {
		sp_in.close();
	} catch (Exception ignored) {
	}
	try {
		sp_out.close();
	} catch (Exception ignored) {
	}
	try {
		sslsock.close();
	} catch (Exception ignored) {
	}
	try {
		sock.close();
	} catch (Exception ignored) {
	}
	try {
		Enumeration e, k;
		Object temp_e;
		Hashtable listeners;
		//clear out the hostnames
/*		for (e = hostnames.keys(); e.hasMoreElements(); ) {
			hostnames.remove(e.nextElement());
		}
		//clear out the accept lists/threads
		for (e = localhosts.keys(); e.hasMoreElements(); ) {
			temp_e = e.nextElement();
			listeners = (Hashtable)localhosts.get(temp_e);
			for (k = listeners.keys(); k.hasMoreElements(); ) {
				listener = (FCP_AcceptThread)listeners.get(k.nextElement());
				listener.terminate(); //calls remove()
			}
			localhosts.remove(temp_e);
		}*/
	} catch (Exception ignored) {
	}
	conn_alive = false;

	importance_threshold = INFO_CRITICAL;
}

public void stop()
{
	//leave the thread running so we can work in the background
}

public void destroy()
{
	//stop the server thread and then do cleanup
	//this is what we should do instead of calling stop(), but
	//currently the sp_in.read() will potentially block forever,
	//so since we don't hold any locks and we're shutting down,
	//just call stop() for now.
	//valid_session = false;
	//try {
	//	server_thread.join();
	//} catch (Exception e) {
	//	//could not do clean shutdown; oh well
	//}
	server_thread.stop();
	terminate();
}

private Socket negotiate_basic(String host, int port)
{
	try {
		Socket sock = null;
		String header, auth_method;
		int status = 0;
		int tries = 0;
		int morebytes = 0;

		auth_method = new String("");
                
		while (status != 200) {
			tries++;
			if (tries > 1) {
				//don't have the right credentials - give up
				throw new Exception("invalid username/password");
			}
			//try to reuse existing credentials first
			//if (username == null || password == null) {
                        if (username == null) {
				get_user_credentials(false, auth_method);
			}

			sock = new Socket(host, port);
			morebytes = 0;

			sp_in = sock.getInputStream();
			sp_out = sock.getOutputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(sp_in));
			buff_out = new BufferedOutputStream(sp_out, 1460);

			//Basic auth info is base64(concat(username, ':', password))
			byte[] auth_info = str2bytes(username+":"+password);
			char[] auth_64 = Base64.encode(auth_info);

			//uncomment to authenticate against a non-proxy host
			//String connect = "GET /exchange/ HTTP/1.0\r\n";
			//String keepalive = "Connection: Keep-Alive\r\n";
			//String basic_auth = "Authorization: Basic ";
			//uncomment to authenticate against a proxy host
			String connect = "CONNECT "+server_name+":"+server_port+" HTTP/1.0\r\n";
			String keepalive = "Proxy-Connection: Keep-Alive\r\n";
			String basic_auth = "Proxy-Authorization: Basic ";

			//send the CONNECT call
			buff_out.write(str2bytes(connect), 0, connect.length());
			buff_out.write(str2bytes(keepalive), 0, keepalive.length());
			buff_out.write(str2bytes(basic_auth), 0, basic_auth.length());
			//kind of hackish, but we need to get the char[] into a byte[]
			auth_info = str2bytes(new String(auth_64));
			buff_out.write(auth_info, 0, auth_info.length);
			buff_out.write(str2bytes("\r\n\r\n"), 0, 4);
			buff_out.flush(); //no more to write
			print_message("Basic Auth sent\n", INFO_NOTICE);

			//read the response
			while ((header = reader.readLine()) != null) {
				print_message("["+header+"]\n", INFO_NOTICE);
				if (header.length() == 0) {
					break; //end of headers
				}
				header.trim();
				if (header.toUpperCase().startsWith("HTTP")) {
					if (header.indexOf("200") > -1) {
						//connection established
						status = 200;
					}
					else if (header.indexOf("407") > -1 || header.indexOf("401") > -1) {
						//we need to authenticate
						status = 407;
					}
					else {
						//bad HTTP status code
						status = 500;
					}
					print_message("HTTP status " + status + "\n", INFO_NOTICE);
				}
				if (header.indexOf(":") < 1) {
					continue; //not a header of form name: value
				}
				if (header.toLowerCase().startsWith("content-length")) {
					//we should never get this from a proxy, but oh well
					morebytes = Integer.parseInt(header.substring(header.indexOf(":")+1).trim());
				}
				//uncomment to authenticate against a non-proxy host
				//if (header.startsWith("WWW-Authenticate") || header.startsWith("www-authenticate")) {
				//uncomment to authenticate against a proxy host
				if (header.toLowerCase().startsWith("proxy-authenticate")) {
					auth_method = header.substring(header.indexOf(":")+1).trim();
					if (auth_method.toLowerCase().startsWith("basic")) {
						//Basic auth - get the Realm
						auth_method = auth_method.substring(auth_method.indexOf(" ")+1).trim();
					}
				}
			}

			if (morebytes > 0) {
				//flush the socket buffer
				print_message("flushing "+morebytes+" bytes\n", INFO_NOTICE);
				reader.skip((long)morebytes);
			}
			//don't close our socket if we succeeded in the inner loop!
			if (status != 200) {
				sock.close();
				sock = null;
				//well, these obviously didn't work
				username = null;
				password = null;
			}
		} //outter while !200 OK

		return sock; //connected
	} catch (Exception e) {
		print_message("Exception while doing Basic: "+e.getMessage()+"\n", INFO_NOTICE);
		return null;
	}
}

private Socket negotiate_ntlm(String host, int port)
{
	try {
		Socket sock = null;
		int status = 0;
		int tries = 0;
		int morebytes = 0;

		while (status != 200) {
			tries++;
			if (tries > 1) {
				//don't have the right credentials - give up
				throw new Exception("invalid username/password/domain");
			}
			//try to reuse existing credentials first
			//if (username == null || password == null || domain == null) {
                        if (username == null) {
				get_user_credentials(true, "");
			}

			sock = new Socket(host, port);

			sp_in = sock.getInputStream();
			sp_out = sock.getOutputStream();
			BufferedReader reader = new BufferedReader(new InputStreamReader(sp_in));
			buff_out = new BufferedOutputStream(sp_out, 1460);

			byte[] ntlm_request = NTLM.formatRequest();
			char[] request_64 = Base64.encode(ntlm_request);

			//uncomment to authenticate against a non-proxy host
			//String connect = "GET /exchange/ HTTP/1.0\r\n";
			//String keepalive = "Connection: Keep-Alive\r\n";
			//String ntlm_auth = "Authorization: NTLM ";
			//uncomment to authenticate against a proxy host
			String connect = "CONNECT "+server_name+":"+server_port+" HTTP/1.0\r\n";
			String keepalive = "Proxy-Connection: Keep-Alive\r\n";
			String ntlm_auth = "Proxy-Authorization: NTLM ";

			//send the CONNECT call
			buff_out.write(str2bytes(connect), 0, connect.length());
			buff_out.write(str2bytes(keepalive), 0, keepalive.length());
			buff_out.write(str2bytes(ntlm_auth), 0, ntlm_auth.length());
			//kind of hackish, but we need to get the char[] into a byte[]
			ntlm_request = str2bytes(new String(request_64));
			buff_out.write(ntlm_request, 0, ntlm_request.length);
			buff_out.write(str2bytes("\r\n\r\n"), 0, 4);
			buff_out.flush(); //no more to write
			print_message("NTLM Negotiate sent\n", INFO_NOTICE);

			//read the response
			String header, auth_method;
			int nonce_tries = 0;

			while (status != 200) {
				auth_method = null;
				morebytes = 0;

				nonce_tries++;
				if (nonce_tries > 2) {
					break; //this isn't working - start over again
				}
				print_message("try "+nonce_tries+"\n", INFO_NOTICE);
				while ((header = reader.readLine()) != null) {
					print_message("["+header+"]\n", INFO_NOTICE);
					if (header.length() == 0) {
						print_message("done with headers\n", INFO_NOTICE);
						break; //end of headers
					}
					header.trim();
					if (header.toUpperCase().startsWith("HTTP")) {
						if (header.indexOf("200") > -1) {
							//connection established
							status = 200;
						}
						else if (header.indexOf("407") > -1 || header.indexOf("401") > -1) {
							//we need to authenticate
							status = 407;
						}
						else {
							//bad HTTP status code
							status = 500;
						}
						print_message("HTTP status " + status + "\n", INFO_NOTICE);
					}
					if (header.indexOf(":") < 1) {
						continue; //not a header of form name: value
					}
					if (header.toLowerCase().startsWith("content-length")) {
						//we should never get this from a proxy, but oh well
						morebytes = Integer.parseInt(header.substring(header.indexOf(":")+1).trim());
					}
					//uncomment to authenticate against a non-proxy host
					//if (header.startsWith("WWW-Authenticate") || header.startsWith("www-authenticate")) {
					//uncomment to authenticate against a proxy host
					if (header.toLowerCase().startsWith("proxy-authenticate")) {
						auth_method = header.substring(header.indexOf(":")+1).trim();
						if (auth_method.toUpperCase().startsWith("NTLM")) {
							//NTLM auth - get the server nonce
							auth_method = auth_method.substring(auth_method.indexOf(" ")+1).trim();
						}
					}
				}
				if (morebytes > 0) {
					//flush the socket buffer
					print_message("flushing "+morebytes+" bytes\n", INFO_NOTICE);
					reader.skip((long)morebytes);
				}
				if (status == 200) {
					print_message("200 OK\n", INFO_NOTICE);
					break; //success!
				}
				if (auth_method == null) {
					print_message("no auth method\n", INFO_NOTICE);
					break; //couldn't find the NTLM auth header???
				}

				//construct and send the ntlm response for final authentication
				byte[] ntlm_challenge = Base64.decode(auth_method.toCharArray());
				if (ntlm_challenge == null) {
					print_message("no challenge\n", INFO_NOTICE);
					break; //couldn't extract the NTLM challenge
				}
				byte[] nonce = NTLM.getNonce(ntlm_challenge);
				if (nonce == null) {
					print_message("no nonce - bad format?\n", INFO_NOTICE);
					break; //couldn't extract the NTLM nonce
				}
				boolean unicode = NTLM.getUnicodeFlag(ntlm_challenge);
				byte[] ntlm_response = NTLM.formatResponse(username, domain,
				                                           NTLM.computeLMpassword(password),
				                                           NTLM.computeNTpassword(password),
				                                           nonce, unicode);
				if (ntlm_response == null) {
					print_message("failed response\n", INFO_NOTICE);
					break; //couldn't format the NTLM response
				}
				char[] response_64 = Base64.encode(ntlm_response);

				//send the CONNECT call
				buff_out.write(str2bytes(connect), 0, connect.length());
				buff_out.write(str2bytes(keepalive), 0, keepalive.length());
				buff_out.write(str2bytes(ntlm_auth), 0, ntlm_auth.length());
				//kind of hackish, but we need to get the char[] into a byte[]
				ntlm_response = str2bytes(new String(response_64));
				buff_out.write(ntlm_response, 0, ntlm_response.length);
				buff_out.write(str2bytes("\r\n\r\n"), 0, 4);
				buff_out.flush(); //no more to write
				print_message("NTLM Response sent\n", INFO_NOTICE);
			} //inner while !200 OK

			//don't close our socket if we succeeded in the inner loop!
			if (status != 200) {
				sock.close();
				//well, these obviously didn't work
				username = null;
				password = null;
				domain = null;
			}
		} //outter while !200 OK

		return sock; //connected
	} catch (Exception e) {
		print_message("Exception while doing NTLM: "+e.getMessage()+"\n", INFO_NOTICE);
		return null;
	}
}

private Socket ssl_disable_client_cert(Socket sock)
{
	try {
		long time = (new Date()).getTime();
		int unixtime = (int)(time / 1000); //convert miliseconds to seconds
		byte[] gmt_unix_time = int2bytes(unixtime, 4);

		//construct the special header for disabling client cert auth
		byte[] tls_header = new byte[82];
		int i = 0, j;

		//TLSv1 Record Layer
		tls_header[i++] = 0x16; //Handshake
		tls_header[i++] = 0x03; tls_header[i++] = 0x01; //major, minor: TLSv1
		tls_header[i++] = 0x00;	tls_header[i++] = 0x4D; //length: 77 bytes
		//Handshake Protocol
		tls_header[i++] = 0x01; //Client Hello
		tls_header[i++] = 0x00; tls_header[i++] = 0x00; tls_header[i++] = 0x49; //length: 73 bytes
		tls_header[i++] = 0x03;	tls_header[i++] = 0x01; //major, minor: TLSv1
		for (j = 0; j < 4; j++) {
			tls_header[i++] = gmt_unix_time[j]; //GMT Unix Time
		}
		for (j = 0; j < 28; j++) {
			tls_header[i++] = (byte)(j+1); //28 bytes of random
		}
		tls_header[i++] = 0x20; //session id length: 32 bytes
		for (j = 0; j < 32; j++) {
			tls_header[i++] = (byte)0xFF; //set all FF as special
		}
		tls_header[i++] = 0x00; tls_header[i++] = 0x02; //cipher suites length
		tls_header[i++] = 0x00; tls_header[i++] = 0x04; //TLS_RSA_WITH_RC4_128_MD5
		tls_header[i++] = 0x01; //compression methods length
		tls_header[i++] = 0x00; //compression method null

		sp_out = sock.getOutputStream();
		buff_out = new BufferedOutputStream(sp_out, 1460);
		buff_out.write(tls_header, 0, tls_header.length);
		buff_out.flush(); //no more to write
	} catch (Exception e) {
		print_message("Error initializing SSL tunnel: " + e.getMessage() + "\n", INFO_NOTICE);
		try { sock.close(); } catch (Exception ignored) { }
		sock = null;
	}

	return sock;
}

public boolean isReady() {
  return m_Ready;
}

public String login(String prmPortal, String prmUsername, String prmPwd) {
	Socket sock; //we could use the global one but...
        InputStream sp_in;
	OutputStream sp_out;
	BufferedOutputStream buff_out;
	int status = 0;
        int i, l;
        String st;
        
        print_message(prmPortal+","+prmUsername, INFO_NOTICE);
        try {
          sock = new Socket(prmPortal, 443);
        } catch (Exception e){
          print_message("Login: Failed to create socket", INFO_NOTICE);
          return "";
        }
        
      l = 0;
      
      short[] ciphers = new short[1];
      ciphers[0] = SSLParams.SSL_RSA_WITH_RC4_128_MD5;

      print_message("Initializing SSL...\n", INFO_NOTICE);
      SpinnerRandomBitsSource spinner = new SpinnerRandomBitsSource(10);
      
      SSLParams params = new SSLParams();
      params.setRNG(spinner);
      params.setClientCipherSuites(ciphers);
      params.setCertVerifier(new SSLCertificateVerifier(false));
      params.setAllowSSL3(false);
      params.setAllowTLS1(true);
      
      try {
        l = 1;  
        sslsock = new SSLSocket(sock, params);
        l = 2;
	sp_in = sslsock.getInputStream();
        l = 3;
	sp_out = sslsock.getOutputStream();
        l = 4;
        BufferedReader reader = new BufferedReader(new InputStreamReader(sp_in));
        l = 5;
	buff_out = new BufferedOutputStream(sp_out, 1460);
        
        l = 6;
        
        String postData = "uname="+prmUsername+"&pwd="+prmPwd;
        Integer pLen = new Integer(postData.length());
        
        String login_post = "POST /prx/000/http/localhost/login HTTP/1.0\r\n" +
				                      "Content-Length: " +pLen.toString()+"\r\n\r\n" +
				                      postData;
        l = 7;
	buff_out.write(str2bytes(login_post), 0, login_post.length());
        
        l = 8;
	buff_out.flush();
        
        l = 9;
        String header;
        
        l = 10;
	while ((header = reader.readLine()) != null) {
          l = 11;   
 	  if (header.length() == 0) {
            l = 12;   
	    break; //end of headers
          }
          
          print_message(header, INFO_NOTICE);
          
          l = 13;
          header.trim();
          
          l = 14;
	  if (header.indexOf(":") < 1) {
            l = 15;  
  	    continue; //not a header of form name: value
	  }
          
          l = 16;
	  if (header.toLowerCase().startsWith("set-cookie")) {
            print_message("Login: found cookie "+header, INFO_NOTICE);
            System.err.println("Login: found cookie "+header);
            i = header.indexOf("ANsess");
            if (i > -1) {
              print_message("Login: Found session cookie", INFO_NOTICE);
              st = header.substring(i);
              i = st.indexOf(";");
              if (i > -1) {
                print_message("Login: Session Cookie is "+st.substring(0, i), INFO_NOTICE);
                return st.substring(0, i);
              }
              
              /*
              i = st.indexOf("=");
              if (i > -1) {
                st = st.substring(i+1);
                
              }*/
            }
          }
        }
      } catch (Exception e){
        Integer I = new Integer(l)  ;
        print_message("Login: Exception "+I.toString(), INFO_NOTICE);
        return "";
      }
        
   return "";
}


} //end FatClientProxy class

