package com.desktopdirect.tcs;

import java.io.*;
import java.net.*;

import crysec.*;

public class NTLM {

//Java bytes are signed, but the crypto algorithms assumed unsigned;
//the bitmask is needed to prevent the signed bit from being extended
private static int unsignedbyte2int(byte b)
{
	return ((int)b & 0xFF);
}

//convert from big endian to little endian for Microsoft
//we need to use >>> rather than >> because we need the signed bit
private static short swapshort(short s)
{
	return (short)(((s << 8) & 0xFF00) | ((s >>> 8) & 0x00FF));
}

//compute an odd DES key from 56 bits of byte array keydata
private static byte[] computeDESkey(byte[] keydata, int offset)
{
	byte[] DESkey = new byte[8];
	int[] k = new int[7];
	int i;

	for(i = 0; i < 7; i++) {
		k[i] = unsignedbyte2int(keydata[offset + i]);
	}

	DESkey[0] = (byte)(k[0] >>> 1);
	DESkey[1] = (byte)(((k[0] & 0x01) << 6) | (k[1] >>> 2));
	DESkey[2] = (byte)(((k[1] & 0x03) << 5) | (k[2] >>> 3));
	DESkey[3] = (byte)(((k[2] & 0x07) << 4) | (k[3] >>> 4));
	DESkey[4] = (byte)(((k[3] & 0x0F) << 3) | (k[4] >>> 5));
	DESkey[5] = (byte)(((k[4] & 0x1F) << 2) | (k[5] >>> 6));
	DESkey[6] = (byte)(((k[5] & 0x3F) << 1) | (k[6] >>> 7));
	DESkey[7] = (byte)(k[6] & 0x7F);

	for (i = 0; i < 8; i++) {
		DESkey[i] = (byte)(unsignedbyte2int(DESkey[i]) << 1);
	}

	return DESkey;
}

//encrypt 8 bytes of plaintext three times (NOT 3DES!) with the three
//56-bit DES keys and puts the results into a 24 byte array.
private static byte[] encrypt(byte[] keys, byte[] plaintext)
{
	byte[] ciphertext = new byte[24];
	byte[] key;

	DES cipher = new DES(DES.ECB); //non-padding ECB encryption

	//once...
	key = computeDESkey(keys, 0);
	cipher.setKey(key);
	cipher.encrypt(plaintext, 0, 8, ciphertext, 0);
	//twice...
	key = computeDESkey(keys, 7);
	cipher.setKey(key);
	cipher.encrypt(plaintext, 0, 8, ciphertext, 8);
	//three time's the charm!
	key = computeDESkey(keys, 14);
	cipher.setKey(key);
	cipher.encrypt(plaintext, 0, 8, ciphertext, 16);

	return ciphertext;
}

//compute the NT hashed password
public static byte[] computeNTpassword(String password)
{
	int i;
	char ch;

	if (password == null) {
		return null;
	}

	//we only use the first 14 characters of the UNICODE password
	int len = password.length();
	if (len > 14) {
		len = 14;
	}

	byte[] nt_pw = new byte[2 * len];
	for (i = 0; i < len; i++) {
		ch = password.charAt(i);
		nt_pw[2 * i] = (byte)(ch & 0xFF); //get the low byte
		nt_pw[2 * i + 1] = (byte)((ch >>> 8) & 0xFF); //high byte
	}

	//return the MD4 digest hash
	MD4 hash = new MD4(nt_pw);
	hash.digest();

	return hash.toBytes();
}

//compute the LM hashed password
public static byte[] computeLMpassword(String password)
{
	//magic number for computing LM hashed password
	byte[] MAGIC = {0x4B, 0x47, 0x53, 0x21, 0x40, 0x23, 0x24, 0x25};
	byte[] lm_pw = new byte[14];  //the password
	byte[] lm_hpw = new byte[16]; //the hashed password
	int len, i;

	if (password == null) {
		return null;
	}

	//we only use the first 14 characters of the ASCII password
	password = password.toUpperCase();
	len = password.length();
	if (len > 14) {
		len = 14;
	}

	//convert from 2-byte Java char to byte
	for (i = 0; i < len; i++) {
    	lm_pw[i] = (byte)(password.charAt(i) & 0xFF);
	}
	for (; i < 14; i++) {
    	lm_pw[i] = 0;
	}

	DES cipher = new DES(DES.ECB); //non-padding ECB encryption
	byte[] key;

	//build the first DES key using the first 7 bytes of pw
	key = computeDESkey(lm_pw, 0);
	cipher.setKey(key);
	//encrypt the MAGIC number using this key into the first 8 bytes of hpw
	cipher.encrypt(MAGIC, 0, 8, lm_hpw, 0);

	//build the second DES key using the last 7 bytes of pw
	key = computeDESkey(lm_pw, 7);
	cipher.setKey(key);
	//encrypt the MAGIC number again into the last 8 bytes of hpw
	cipher.encrypt(MAGIC, 0, 8, lm_hpw, 8);

	return lm_hpw;
}

//compute the NTLM response to the nonce, based on the hashed passwords
//the following data size restrictions are enforced:
//  nt_hpw : NT hashed password, 16 bytes
//  lm_hpw : LM hashed password, 16 bytes
//  nonce  : server nonce, 8 bytes
//  nt_resp : NT response, 24 bytes
//  lm_resp : LM response, 24 bytes
public static void computeNTLMresponse(byte[] lm_hpw, byte[] nt_hpw,
		byte[] nonce, byte[] lm_resp, byte[] nt_resp)
	throws Exception
{
	int i;

	if (lm_hpw.length != 16) {
		throw new Exception("LM Password hash wrong size");
	}
	if (nt_hpw.length != 16) {
		throw new Exception("NT Password hash wrong size");
	}
	if (nonce.length != 8) {
		throw new Exception("nonce wrong size");
	}
	if (lm_resp.length != 24) {
		throw new Exception("LM Response buffer wrong size");
	}
	if (nt_resp.length != 24) {
		throw new Exception("NT Response buffer wrong size");
	}

	//copy the hashed passwords into 21 byte arrays, zero fill
	//this is because we use them as the DES keys in encrypt()
	byte[] lm_hpw_21 = new byte[21];
	byte[] nt_hpw_21 = new byte[21];
	for (i = 0; i < 16; i++) {
		lm_hpw_21[i] = lm_hpw[i];
		nt_hpw_21[i] = nt_hpw[i];
	}
	for (i = 16; i < 21; i++) {
		lm_hpw_21[i] = 0;
		nt_hpw_21[i] = 0;
	}

	//use temp buffers so we can copy into the provided ones
	byte[] temp_lm_resp = encrypt(lm_hpw_21, nonce);
	byte[] temp_nt_resp = encrypt(nt_hpw_21, nonce);
	for (i = 0; i < 24; i++) {
		lm_resp[i] = temp_lm_resp[i];
		nt_resp[i] = temp_nt_resp[i];
	}
}

//extract the nonce from the server challenge
public static byte[] getNonce(byte[] challenge)
{
	int i;

	//technically it should be 36 bytes
	if (challenge.length < 32) {
		return null; //too short
	}

	//copy out the nonce - bytes 25 through 32
	byte[] nonce = new byte[8];
	for (i = 24; i < 32; i++) {
		nonce[i-24] = challenge[i];
	}

	return nonce;
}

//extract the flags and return whether UNICODE is supported
public static boolean getUnicodeFlag(byte[] challenge)
{
	int i;

	//copy out the flags - bytes 21 through 24
	byte[] flags = new byte[4];
	for (i = 20; i < 24; i++) {
		flags[i-20] = challenge[i];
	}

	//the flags are stored in little endian
	return ((flags[0] & 0x01) == 0x01); //unicode bit
}

//format an NTLM request
public static byte[] formatRequest()
	throws IOException
{
	ByteArrayOutputStream os = new ByteArrayOutputStream(1024);
	DataOutputStream dataOut = new DataOutputStream(os);

	//we use a DataOutputStream because writeBytes(String) discards
	//the high 8 bits, which is what we want, and saves us the effort

	//signature
	dataOut.writeBytes("NTLMSSP\0");
	//message type
	dataOut.writeByte(0x01); //NTLM_TYPE_NEGOTIATE
	dataOut.writeByte(0x00);
	dataOut.writeByte(0x00);
	dataOut.writeByte(0x00);
	//flags - little endian
	dataOut.writeByte(0x07);
	dataOut.writeByte(0x82);
	dataOut.writeByte(0x00);
	dataOut.writeByte(0x80);
	//domain information
	dataOut.writeShort(0x0000); //length
	dataOut.writeShort(0x0000); //max length
	dataOut.writeShort(0x0000); //offset (0x20 + hostlen if domain)
	dataOut.writeShort(0x0000);
	//host information
	dataOut.writeShort(0x0000); //length
	dataOut.writeShort(0x0000); //max length
	dataOut.writeShort(0x0000); //offset (0x20 if host)
	dataOut.writeShort(0x0000);
	//host then domain would go here if we had them

	dataOut.writeByte(0x00); //what's this for? who knows

	dataOut.flush();

	return os.toByteArray();
}

public static byte[] formatResponse(String user, String domain,
		byte[] lm_hpw, byte[] nt_hpw, byte[] nonce, boolean unicode)
	throws Exception
{
	if (user == null || domain == null ||
	    lm_hpw == null || lm_hpw.length != 16 ||
	    nt_hpw == null || nt_hpw.length != 16 ||
	    nonce == null || nonce.length != 8)
	{
		return null;
	}

	byte[] lm_resp = new byte[24];
	byte[] nt_resp = new byte[24];
	computeNTLMresponse(lm_hpw, nt_hpw, nonce, lm_resp, nt_resp);

	String host = new String("ARRAYSP"); //fixed string for host
	domain = domain.toUpperCase();

	short lmRespLen = (short)0x18;
	short ntRespLen = (short)0x18;
	short domainLen = (unicode ? (short)(2 * domain.length())
	                           : (short)domain.length());
	short hostLen   = (unicode ? (short)(2 * host.length())
	                           : (short)host.length());
	short userLen   = (unicode ? (short)(2 * user.length())
	                           : (short)user.length());
	short domainOff = (short)0x40;
	short userOff   = (short)(domainOff + domainLen);
	short hostOff   = (short)(userOff + userLen);
	short lmRespOff = (short)(hostOff + hostLen);
	short ntRespOff = (short)(lmRespOff + lmRespLen);
	short msgLen    = (short)(ntRespOff + ntRespLen);

	ByteArrayOutputStream os = new ByteArrayOutputStream(1024);
	DataOutputStream dataOut = new DataOutputStream(os);

	//signature
	dataOut.writeBytes("NTLMSSP\0");
	//message type
	dataOut.writeByte(0x03); //NTLM_TYPE_AUTHENTICATE
	dataOut.writeByte(0x00);
	dataOut.writeByte(0x00);
	dataOut.writeByte(0x00);
	//LM response info
	dataOut.writeShort(swapshort(lmRespLen)); //length
	dataOut.writeShort(swapshort(lmRespLen)); //max length
	dataOut.writeShort(swapshort(lmRespOff)); //offset
	dataOut.writeShort(0x0000);
	//NT response info
	dataOut.writeShort(swapshort(ntRespLen)); //length
	dataOut.writeShort(swapshort(ntRespLen)); //max length
	dataOut.writeShort(swapshort(ntRespOff)); //offset
	dataOut.writeShort(0x0000);
	//domain info
	dataOut.writeShort(swapshort(domainLen)); //length
	dataOut.writeShort(swapshort(domainLen)); //max length
	dataOut.writeShort(swapshort(domainOff)); //offset
	dataOut.writeShort(0x0000);
	//username info
	dataOut.writeShort(swapshort(userLen)); //length
	dataOut.writeShort(swapshort(userLen)); //max length
	dataOut.writeShort(swapshort(userOff)); //offset
	dataOut.writeShort(0x0000);
	//host info
	dataOut.writeShort(swapshort(hostLen)); //length
	dataOut.writeShort(swapshort(hostLen)); //max length
	dataOut.writeShort(swapshort(hostOff)); //offset
	dataOut.writeShort(0x0000);
	//not used
	dataOut.writeInt(0x00000000);
	//length of entire message
	dataOut.writeShort(swapshort(msgLen));
	dataOut.writeShort(0x0000);
	//flags - little endian
	if (unicode) {
		dataOut.writeByte(0x05); //set the unicode bit
	} else {
		dataOut.writeByte(0x04); //don't set unicode
	}
	dataOut.writeByte(0x82);
	dataOut.writeByte(0x80);
	dataOut.writeByte(0x80);

	int i;
	for (i = 0; i < domain.length(); i++) {
		if (unicode) {
			dataOut.writeShort(swapshort((short)domain.charAt(i)));
		} else {
			dataOut.writeByte((byte)domain.charAt(i));
		}
	}
	for (i = 0; i < user.length(); i++) {
		if (unicode) {
			dataOut.writeShort(swapshort((short)user.charAt(i)));
		} else {
			dataOut.writeByte((byte)user.charAt(i));
		}
	}
	for (i = 0; i < host.length(); i++) {
		if (unicode) {
			dataOut.writeShort(swapshort((short)host.charAt(i)));
		} else {
			dataOut.writeByte((byte)host.charAt(i));
		}
	}
	dataOut.write(lm_resp);
	dataOut.write(nt_resp);

	dataOut.flush();

	return os.toByteArray();
}

} //end NTLM class

