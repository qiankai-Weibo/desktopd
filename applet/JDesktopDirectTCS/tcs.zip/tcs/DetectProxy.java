package com.desktopdirect.tcs;

import java.util.*;

public class DetectProxy {

private String proxy_host;
private int proxy_port;

private boolean bypassing_proxy(String proxy_bypass, String server_name)
{
	if (proxy_bypass != null && proxy_bypass.length() > 0) {
		proxy_bypass = proxy_bypass.toLowerCase();
		StringTokenizer strtok = new StringTokenizer(proxy_bypass, ",");
		int tokens = strtok.countTokens();
		if (tokens > 0) {
			for (int i = 0; i < tokens; i++) {
				proxy_bypass = strtok.nextToken().trim();
				if (proxy_bypass.length() < 1) {
					continue;
				}
				if (proxy_bypass.startsWith("*")) {
					if (proxy_bypass.length() > 1) {
						proxy_bypass = proxy_bypass.substring(1);
					} else {
						return true;
					}
				}
				if (proxy_bypass.endsWith("*")) {
					if (proxy_bypass.length() > 1) {
						proxy_bypass = proxy_bypass.substring(0, proxy_bypass.length()-2);
					} else {
						return true;
					}
				}
				if (server_name.startsWith(proxy_bypass) || server_name.endsWith(proxy_bypass)) {
					return true;
				}
			}
		}
	}
	return false;
}

public DetectProxy(FatClientProxy owner, String server_name, int server_port, netscape.javascript.JSObject win)
{
	String vendor, proxy_type, proxy_bypass;

	StringTokenizer strtok;
	int i, tokens;

	this.proxy_host = null;
	this.proxy_port = -1;

	try {
		netscape.security.PrivilegeManager.enablePrivilege("UniversalPropertyRead");
	} catch (Exception e) {
		//Internet Explorer - permissions managed in the certificate
	}

	owner.print_message("Attempting to detect proxy settings...\n", FatClientProxy.INFO_NOTICE);
	try {
		vendor = System.getProperty("java.vendor");
		if (vendor.indexOf("Microsoft") > -1) {
			owner.print_message("Detected Microsoft VM\n", FatClientProxy.INFO_NOTICE);

			if (System.getProperty("http.proxyHost") == null ||
			    System.getProperty("http.proxyPort") == null)
			{
				owner.print_message("proxy type is direct or auto\n", FatClientProxy.INFO_NOTICE);

				//is it a configuration script?
				String proxy_info = (String)win.eval("FindProxyForURL_wrapper(\"http://" +
				                     server_name + ":" + server_port + "/\",\"" + server_name + "\");");
				proxy_info = proxy_info.toLowerCase();

				owner.print_message("proxy info: " + proxy_info + "\n", FatClientProxy.INFO_NOTICE);

				//format: TYPE host:port;...
				strtok = new StringTokenizer(proxy_info, ";");
				tokens = strtok.countTokens();
				for (i = 0; i < tokens; i++) {
					proxy_info = strtok.nextToken().trim();
					if (proxy_info.startsWith("direct")) {
						//no proxy needed
						break;
					}
					if (proxy_info.startsWith("socks")) {
						//we should probably set the socksProxyHost and/or firewallHost properties
						break;
					}
					if (proxy_info.startsWith("proxy") && proxy_info.length() > 9) {
						int port_start = proxy_info.indexOf(":") + 1;
						if (port_start > 1 && port_start < proxy_info.length()) {
							owner.print_message("proxy type is script\n", FatClientProxy.INFO_NOTICE);
							this.proxy_port = Integer.parseInt(proxy_info.substring(port_start));
							this.proxy_host = proxy_info.substring(proxy_info.indexOf(" ")+1, port_start-1);
							break;
						}
					}
					//unknown or improperly formatted entry - skip it
				}
				//assume direct - nothing to do
			} else {
				//manual configuration
				owner.print_message("proxy type is manual\n", FatClientProxy.INFO_NOTICE);

				this.proxy_host = System.getProperty("http.proxyHost");
				this.proxy_port = Integer.parseInt(System.getProperty("http.proxyPort"));
				proxy_bypass = System.getProperty("http.nonProxyHosts");
				if (bypassing_proxy(proxy_bypass, server_name)) {
					owner.print_message("SP is on bypass list\n", FatClientProxy.INFO_NOTICE);
					this.proxy_host = server_name;
					this.proxy_port = server_port;
				}
			}
		} else { //assume Sun
			proxy_type = System.getProperty("javaplugin.proxy.config.type");
			if (proxy_type == null) {
				throw new Exception("could not determine configuration type");
			}
			proxy_type = proxy_type.toLowerCase();

			if (proxy_type.compareTo("direct") == 0) {
				owner.print_message("proxy type is direct\n", FatClientProxy.INFO_NOTICE);
				//nothing to do
			}
			if (proxy_type.compareTo("auto") == 0) {
				owner.print_message("proxy type is script\n", FatClientProxy.INFO_NOTICE);

				String proxy_info = (String)win.eval("FindProxyForURL_wrapper(\"http://" +
				                     server_name + ":" + server_port + "/\",\"" + server_name + "\");");
				proxy_info = proxy_info.toLowerCase();

				owner.print_message("proxy info: " + proxy_info + "\n", FatClientProxy.INFO_NOTICE);

				//format: TYPE host:port;...
				strtok = new StringTokenizer(proxy_info, ";");
				tokens = strtok.countTokens();
				for (i = 0; i < tokens; i++) {
					proxy_info = strtok.nextToken().trim();
					if (proxy_info.startsWith("direct")) {
						//no proxy needed
						break;
					}
					if (proxy_info.startsWith("socks")) {
						//we should probably set the socksProxyHost and/or firewallHost properties
						break;
					}
					if (proxy_info.startsWith("proxy") && proxy_info.length() > 9) {
						int port_start = proxy_info.indexOf(":") + 1;
						if (port_start > 1 && port_start < proxy_info.length()) {
							this.proxy_port = Integer.parseInt(proxy_info.substring(port_start));
							this.proxy_host = proxy_info.substring(proxy_info.indexOf(" ")+1, port_start-1);
							break;
						}
					}
					//unknown or improperly formatted entry - skip it
				}
			}
			if (proxy_type.compareTo("manual") == 0) {
				owner.print_message("proxy type is manual\n", FatClientProxy.INFO_NOTICE);

				String proxy_list = System.getProperty("javaplugin.proxy.config.list");
				//format: protocol=host:port,...
				if (proxy_list != null && proxy_list.length() > 0) {
					proxy_list = proxy_list.toLowerCase();
					strtok = new StringTokenizer(proxy_list, ",");
					tokens = strtok.countTokens();
					for (i = 0; i < tokens; i++) {
						proxy_list = strtok.nextToken().trim();
						int port_start = proxy_list.indexOf(":") + 1;
						int host_start = proxy_list.indexOf("=") + 1;

						if (host_start == 0 || proxy_list.startsWith("http=")) {
							if (port_start > 6 && port_start < proxy_list.length()) {
								this.proxy_port = Integer.parseInt(proxy_list.substring(port_start));
								this.proxy_host = proxy_list.substring(host_start, port_start-1);
								break;
							}
						}
					}
				}
				proxy_bypass = System.getProperty("javaplugin.proxy.config.bypass");
				if (bypassing_proxy(proxy_bypass, server_name)) {
					owner.print_message("SP is on bypass list\n", FatClientProxy.INFO_NOTICE);
					this.proxy_host = server_name;
					this.proxy_port = server_port;
				}
			} //end "manual"
		}
	} catch (Exception f) {
		owner.print_message("error detecting proxy: " + f.getMessage() + "\n", FatClientProxy.INFO_STATUS);
		this.proxy_host = server_name;
		this.proxy_port = server_port;
	}

	if (this.proxy_host == null || this.proxy_port < 0 || this.proxy_port > 65535) {
		this.proxy_host = server_name;
		this.proxy_port = server_port;
	}

	owner.print_message("detected "+this.proxy_host+":"+this.proxy_port+"\n", FatClientProxy.INFO_NOTICE);
}

public String getHost()
{
	return this.proxy_host;
}

public int getPort()
{
	return this.proxy_port;
}

} //end DetectProxy class

